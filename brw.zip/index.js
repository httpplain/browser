require('events').EventEmitter.defaultMaxListeners = 0;
const puppeteer = require('puppeteer-extra')
const RecaptchaPlugin = require('puppeteer-extra-plugin-recaptcha');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

let BypassNum=0;
//db.set(message.id, { status: "processing", url: message.url })
const Token = [
	'e434221e110a2c6795a5ea0b0b37b475',
	'63651e7f20dd83f1270aa0fa394fb2a2',
	'd7f6b3260c029027293c9e9e133c1ead',
	'612c8a3d6113a089cb3d94d1510ef607',
	'67dd29dd93bcfe3f5b451451b6d98226',
	'589413974562599950cdfcf438c2cd45',
	'92f2f86ffc226783191508dc6f26fdb9'
]
function solving(message){
	var key = Token[Math.floor(Math.random() * Token.length)];
    return new Promise((resolve,reject) => {
       //console.log(`正在启动浏览器`)
        puppeteer.use(StealthPlugin())
        puppeteer.use(RecaptchaPlugin({
            provider: {
                id:'2captcha',
                token:key
            },
            visualFeedback:true
        }))
        puppeteer.launch({
        	  executablePath:'/usr/bin/chromium-browser',
            headless: true,
            args: [
                `--proxy-server=http://${message.proxy}`,
                '--disable-features=IsolateOrigins,site-per-process,SitePerProcess',
                '--flag-switches-begin --disable-site-isolation-trials --flag-switches-end',
                `--window-size=1920,1080`,
                "--window-position=000,000",
                "--disable-dev-shm-usage",
                "--no-sandbox",
              ]
        }).then(async (browser) => {
            console.log(`连接代理中 【武涛专属浏览器v1脚本 TG:WuTao8888】 Proxy: ${message.proxy}`)
            const page = await browser.newPage()
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36 OPR/84.0.4316.21');
            await page.setJavaScriptEnabled(true);
            await page.setDefaultNavigationTimeout(120000);
            await page.evaluateOnNewDocument(() => {
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => false
                });
            })
            await page.evaluateOnNewDocument(() => {
                Object.defineProperty(navigator, 'platform', {
                    get: () => 'Win32'
                });
            })
            try {
                console.log(`绕过目标中【武涛专属浏览器v1脚本 TG:WuTao8888】 目标: ${message.url} | Proxy: ${message.proxy}`)
                var admv = await page.goto(String(message.url).replace("[rand]",""))
               // BypassNum++
                console.log(`绕过成功 【武涛专属浏览器v1脚本 TG:WuTao8888】 目标: ${message.url} | Proxy: ${message.proxy}`)
                
            } catch (error) {
                //db.set(message.id, { status: "error_connect", url: message.url,error:error.message})
                // console.log(error)
                reject(error)
                await browser.close()
            }
            
            try {
                const cloudFlareWrapper = await page.$('#cf-wrapper'); 
                console.log(cloudFlareWrapper)
                if (cloudFlareWrapper) {
                    console.log(`目标好像是验证码 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                    await page.waitForTimeout(10000, { waitUntil:'networkidle0' })
                    const maybecaptcha = await page.$('#cf-hcaptcha-container');
                    if (maybecaptcha) {
                        try {
                            await page.waitForSelector('#cf-hcaptcha-container'); 
                            console.log(`正在尝试绕过 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                            await page.solveRecaptchas();
                        } catch (e) {
                            console.log(`绕过成功 开始进攻 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                        }
                    }
                    console.log(`目标是JS验证 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                }
                await page.waitForTimeout(30000, { waitUntil: 'networkidle0' })
                const cloudFlareWrapper2 = await page.$('#cf-wrapper'); 
                if (cloudFlareWrapper2) {
                   console.log(`目标好像是验证码 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                    await page.waitForTimeout(10000, { waitUntil:'networkidle0' })
                    const maybecaptcha2 = await page.$('#cf-hcaptcha-container');
                    if (maybecaptcha2) {
                        try {
                            await page.waitForSelector('#cf-hcaptcha-container'); 
                            console.log(`正在尝试绕过 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                            await page.solveRecaptchas();
                        } catch (e) {
                            console.log(`绕过成功 开始进攻 | 目标: ${message.url} | Proxy: ${message.proxy}`)
                        }
                    }
                   console.log(`目标是JS验证| 目标: ${message.url} | Proxy: ${message.proxy}`)
                    await page.waitForTimeout(30000, { waitUntil: 'networkidle0' })
                    const cloudFlareWrapper3 = await page.$('#cf-wrapper'); 
                    if (cloudFlareWrapper3) {
                       console.log(`暂时无法绕过| 目标: ${message.url} | Proxy: ${message.proxy}`)
                        await browser.close();
                        reject();
                        return;
                    }
                }
                const cookies = await page.cookies()
               console.log(`正在记录Cookies | 目标: ${message.url} | Proxy: ${message.proxy}`)
                if (cookies) {
                    console.log(`正在记录Cookies| 目标: ${message.url} | Proxy: ${message.proxy}`)
                   console.log(` Cookies: ${cookies.length} `)
                    resolve(cookies);
                    await browser.close();
                    return;
                    //return cookies
                }
            } catch (ee) { 
                reject(ee)
                await browser.close();
            }
            
            // let db = new JSONdb('database.json');
            // db.set(message.id, { status: "done", url: message.url, cookies: cookies, useragent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36 OPR/84.0.4316.21" })
        })
        
    })
}

module.exports = { solving:solving }

// solving({
//     "url":process.argv[2],
//     "proxy":"45.129.125.43:3128"
// }).then((cookie) => {
//     console.log(cookie)
// })
