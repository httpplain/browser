#!/bin/bash
apt install -y wget tar
wget https://nodejs.org/dist/v14.17.1/node-v14.17.1-linux-x64.tar.xz
rm -irf nodejs
tar xf node-v14.17.1-linux-x64.tar.xz
rm -f node-v14.17.1-linux-x64.tar.xz
mv node-v14.17.1-linux-x64 nodejs
rm -f /usr/local/bin/npm
rm -f /usr/local/bin/node
ln -s ~/nodejs/bin/npm /usr/local/bin/
ln -s ~/nodejs/bin/node /usr/local/bin/
apt install -y npm
npm i randomstring
npm i http2
npm i url
npm i cluster
npm i fs
npm i path
npm i ip
npm i md5
npm i request
npm i colors
npm i puppeteer-extra-plugin-recaptcha
npm i puppeteer-extra
npm i puppeteer-extra-plugin-stealth
npm i puppeteer-core
npm i fake-useragent
apt install chromium-browser -y