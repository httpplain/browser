/*
    Default Addon for CDNFLY
    
    - Velocity
*/

const colors = require('colors');

function log(string) {
    let d = new Date();
    let hours = (d.getHours() < 10 ? '0' : '') + d.getHours();
    let minutes = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    let seconds = (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();
    console.log(`(${hours}:${minutes}:${seconds})`.white + ` - ${string}`);
}

async function sliderSolver(page, context, response) {
    log(`(${'VELOCITY++'.green}) Detected protection -> ` + `cdnfly (Slider)`.green);

    await page.waitForTimeout(15000);

    await page.evaluate(() => {
        let slider = document.querySelector("#slider > div.tips");
        let btn = document.querySelector("#btn");

        let sliderRect = slider.getBoundingClientRect();
        let btnRect = btn.getBoundingClientRect();

        let endPos = sliderRect.right + 10;

        let mouseDownEvent = new MouseEvent("mousedown", {
            bubbles: true,
            clientX: btnRect.left,
            clientY: btnRect.top
        });

        btn.dispatchEvent(mouseDownEvent);

        let moveBtn = (currentPos) => {
            if (currentPos < endPos) {
                let mouseMoveEvent = new MouseEvent("mousemove", {
                    bubbles: true,
                    clientX: currentPos,
                    clientY: btnRect.top
                });

                btn.dispatchEvent(mouseMoveEvent);

                setTimeout(() => {
                    moveBtn(currentPos + 1);
                }, (3000 / (endPos - btnRect.left)));
            } else {
                let mouseUpEvent = new MouseEvent("mouseup", {
                    bubbles: true,
                    clientX: currentPos,
                    clientY: btnRect.top
                });

                btn.dispatchEvent(mouseUpEvent);
            }
        };

        moveBtn(btnRect.left);
    });

    await page.waitForTimeout(15000);

    var title;
    var cookies;
    var headers;
    var headerEntries;

    try { 
        title = await page.title();
        cookies = (await context.cookies()).map(c => `${c.name}=${c.value}`).join('; ');
        headers = await response.request().allHeaders();
        headerEntries = Object.entries(headers);
    } catch (e) {
        await page.waitForTimeout(10000);

        title = await page.title();
        cookies = (await context.cookies()).map(c => `${c.name}=${c.value}`).join('; ');
        headers = await response.request().allHeaders();
        headerEntries = Object.entries(headers);
    }

    return [title, cookies, headerEntries];
}

function initialize() { }

module.exports = {
    initialize: initialize,
    sliderSolver: sliderSolver
};