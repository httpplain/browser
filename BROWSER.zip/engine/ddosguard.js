/*
    Default Addon for DDoS Guard
    
    - ORBITAL STRESS
*/


const colors = require('colors');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

function log(string) {
    let d = new Date();
    let hours = (d.getHours() < 10 ? '0' : '') + d.getHours();
    let minutes = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
    let seconds = (d.getSeconds() < 10 ? '0' : '') + d.getSeconds();
    console.log(`(${hours}:${minutes}:${seconds})`.white + ` - ${string}`);
}

const SITE_KEY_REGEXP = /sitekey=([^"]+)/;

function extract(string, regexp, errorMessage) {
    const match = string.match(regexp);
    if (match) {
        return match[1];
    }
    if (errorMessage) {
        throw new Error(errorMessage);
    }
}

function httpGet(theUrl) {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", theUrl, false);
    xmlHttp.send(null);
    return xmlHttp.responseText;
}

function sendCaptcha(siteKey, page, callback) {
    var keyCaptchaParams = "https://2captcha.com/in.php?key=e434221e110a2c6795a5ea0b0b37b475&method=hcaptcha&sitekey=" + siteKey + "&pageurl=" + urlT + "&json=1";
    var captchaId = JSON.parse(httpGet(keyCaptchaParams)).request;
    var keyCaptchaResponse = "https://2captcha.com/res.php?key=" + "e434221e110a2c6795a5ea0b0b37b475" + "&action=get&header_acao=1&json=1&id=" + captchaId;

    (async function () {
        await page.waitForTimeout(25000);
    })

    var intId = setInterval(function () {
        var captchaAnswer = JSON.parse(httpGet(keyCaptchaResponse));

        if (captchaAnswer.status == 1) {
            clearInterval(intId);
            var answer = captchaAnswer.request;
            log(`(${'Protection Detect'.cyan}) Captcha bypassed ->` + `[ HCaptcha ]`.cyan);

            callback(answer);
        } else if (captchaAnswer.request === "ERROR_CAPTCHA_UNSOLVABLE") {
            clearInterval(intId);
            log(`(${'BYPASSED'.cyan}) Captcha bot bypassed ->` + `[ HCaptcha ]`.cyan);
        }
    }, 5000);
}

async function captchaSolver(page, context, response) {
    log(`(${'Protection Detect'.yellow}) Detected protection -> ` + `DDoS Guard`.brightYellow);

    await page.waitForTimeout(15000);

    if (await page.content().includes('/.well-known/ddos-guard/check?context=free_splash')) {
        const isCaptchaLoaded = await page.locator('[name=h-captcha-response]');

        if (isCaptchaLoaded) {
            log(`(${'Protection Detect'.yellow}) DDG Challenge -> ` + `H-CAPTCHA`.brightYellow);

            let content = await page.content();
            const siteKey = await extract(content, SITE_KEY_REGEXP, "could't find the site key");

            if (siteKey) {
                log(`(${'Protection Detect'.brightCyan}) Detected element -> ` + `[ ${siteKey} ]`.brightCyan);

                sendCaptcha(siteKey, page, async function (captchaResponse) {
                    await page.evaluate((captchaResponse) => {
                        document.querySelector('[name=h-captcha-response]').innerText = captchaResponse;
                    }, captchaResponse);

                    await page.waitForTimeout(7500);
                });
            }
        }
    }

    const title = await page.title();
    const cookies = (await context.cookies()).map(c => `${c.name}=${c.value}`).join('; ');
    const headers = await response.request().allHeaders();
    const headerEntries = Object.entries(headers);

    return [title, cookies, headerEntries];
}

function initialize() { }

module.exports = {
    initialize: initialize,
    captchaSolver: captchaSolver
};